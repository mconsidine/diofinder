from .star_detect import *

__doc__ = star_detect.__doc__
if hasattr(star_detect, "__all__"):
    __all__ = star_detect.__all__